def report(guess, secret):
    in_place = 0
    out_place = 0
    guessed_colors = []
    correct_place_colors = []
    output = []
    for color in range(len(guess)):
        if guess[color] in secret:
            if guess[color] == secret[color]:
                in_place += 1
                correct_place_colors += guess[color]
            elif guess[color] not in correct_place_colors:
                out_place += 1
                guessed_colors += guess[color]
    output += [in_place, out_place]
    print correct_place_colors
    print guessed_colors
    return output