def dice(n):
    sum = 0
    potential_roles = [1,2,3,4,5,6]
    for choices in range(n):
        sum += random.choice(potential_roles)
    print 'Roll was ' + str(sum)
