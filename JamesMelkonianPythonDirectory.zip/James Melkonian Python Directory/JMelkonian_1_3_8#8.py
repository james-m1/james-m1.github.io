def goguess():
    difference = ''
    guesses = 1
    correct_value = random.choice(range(1,20))
    print ('I have a number between 1 and 20 inclusive.')
    guess = int(raw_input('Guess:'))
    while guess != correct_value:
        guesses += 1
        if guess > correct_value:
            difference = 'high.'
            print (str(guess) + ' is too ' + difference)
        else:
            difference = 'low.'
            print (str(guess) + ' is too ' + difference)
        guess = int(raw_input('Guess:'))
    print ('Right! My number is ', str(guess), '! You guessed in ', str(guesses), ' guesses!', sep='')