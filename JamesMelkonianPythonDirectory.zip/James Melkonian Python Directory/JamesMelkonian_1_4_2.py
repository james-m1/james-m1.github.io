# -*- coding: utf-8 -*-
'''
JMelkonian_1_4_2: Read and show an image.
'''
import matplotlib.pyplot as plt 
import os.path
import numpy as np      # “as” lets us use standard abbreviations

'''Read the image data'''
# Get the directory of this python script
directory = os.path.dirname(os.path.abspath(__file__)) 
# Build an absolute filename from directory + filename
filename = os.path.join(directory, 'faces.jpg')
# Read the image data into an array
img = plt.imread(filename)

'''Show the image data'''
# Create figure with 1 subplot
# Create a 1x2 grid of subplots
# fig is the Figure, and ax is an ndarray of AxesSubplots
# ax[0] and ax[1] are the two Axes Subplots
fig, ax = plt.subplots(1, 1)
# Show the image data in the first subplot
#for x in range(5):
ax.imshow(img, interpolation='none')
# Draw circles on the eyes.
ax.plot(64,102,'ro')
ax.plot(101,102,'ro')
ax.plot(224,102,'ro')
ax.plot(260,102,'ro')
ax.plot(385,102,'ro')
ax.plot(419,102,'ro')

# Limit size of plot
ax.set_xlim(0,478)
#ax[0].imshow(img, interpolation='none')
# Show the image data in the second subplot
#ax[1].imshow(img, interpolation='none')
# Show the figure on the screen

fig.show()

