from __future__ import print_function
import random

def validate():
    guess = '1' # initialization with a bad guess
    answer = 'hangman word'
    while guess not in answer:
        guess = raw_input('Name a letter in \''+answer+'\': ')
    print('Thank you!')
    

def guess_winner(players=('Amy', 'Bill', 'Cathy', 'Dale')):
    '''Function takes a tuple for an argument. 
    If no input is given,  the argument is set to the tuple players.
    The function then asks for a guess of who won the lottery.
    User inputs a value from the argument.
    If the input is equal to the lottery winner, the function Prints the number of guesses made.
    Otherwise, it says to guess again and takes another input.
    The value returned is a string output.
    '''
    winner = random.choice(players) 

    ####
    # The string 'Guess which of these people won the lottery: ' is printed.
    # Each element of the argument tuple is printed in succession separated by commas.
    ####
    print('Guess which of these people won the lottery: ',end='')
    for p in players[:len(players)-1]: # Goes through each element of tuple and prints all but the last one. Each element is followed by a comma.
        print(p+', ', end='')
    print(players[len(players)-1]) # Prints the last element of the tuple and does not print a comma after it.

 ####
 # The number of guesses is set to variable.
 # While the user does not enter the correct winner, the number of guesses increases.
 # The user is also prompted to provide another input guess.
 # Once the input is equal to the winner, the number of guesses is printed and returned.
 ####
    guesses = 1 
    while raw_input() != winner:
        print('Guess again!')
        guesses += 1
    print('You guessed in', guesses, 'guesses!')
    return guesses 
    
def goguess():
    difference = ''
    guesses = 1
    correct_value = random.choice(range(1,20))
    print ('I have a number between 1 and 20 inclusive.')
    guess = int(raw_input('Guess:'))
    while guess != correct_value:
        guesses += 1
        if guess > correct_value:
            difference = 'high.'
            print (str(guess) + ' is too ' + difference)
        else:
            difference = 'low.'
            print (str(guess) + ' is too ' + difference)
        guess = int(raw_input('Guess:'))
    print ('Right! My number is ', str(guess), '! You guessed in ', str(guesses), ' guesses!', sep='')