def add_tip(total, tip_percent): 
    ''' Return the total amount including tip
    '''
    tip = tip_percent*total
    return total + tip

def hyp(leg1, leg2):
    ''' Return the length of the hypotenuse of a right triangle
    '''
    return (leg1**2 + leg2**2)**0.5

def mean(a, b, c):
    ''' Return the arithmetic mean of a, b, and c
    '''
    return (a+b+c)/3.0

def perimeter(base, height):
    ''' Return the perimeter of a rectangle with base and heigh inputs
    '''
    return (2*base + 2*height)
    
