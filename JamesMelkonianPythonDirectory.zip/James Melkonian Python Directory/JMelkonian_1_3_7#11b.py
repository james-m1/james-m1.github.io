def matches(ticket, winners):
    matching = 0
    for number in ticket:
        if number in winners:
            matching += 1
    return matching