def roll_hundred_pair():
    total = []
    potential_roles = [1,2,3,4,5,6]
    for choices in range(100):
        total += [random.choice(potential_roles)]
    
    plt.hist(total)
    plt.show()