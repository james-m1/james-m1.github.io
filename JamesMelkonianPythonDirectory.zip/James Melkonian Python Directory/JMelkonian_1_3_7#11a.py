def hangman_display(guessed, secret):
    output = ''
    #for y in guessed:    
    for x in range(len(secret)):
        if ' ' == secret[x]:
            output += ' '
            #print '1 ' + output #for debugging
        elif secret[x] in guessed:
            output += secret[x]
            #print '2 ' + output #for debugging
        else:
            output += '-'
            #print '3 ' + output #for debugging
    return output