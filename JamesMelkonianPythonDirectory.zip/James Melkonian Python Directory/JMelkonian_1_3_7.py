# -*- coding: utf-8 -*-
def days():
    ''' Outputs the days of the week.
        It also outputs the nth day of September
        from the 5th to the 7th.
    '''
    for day in 'MTWRFSS': 
        print(day + 'day')
    for day in range(5,8):
        print('It is the ' + str(day) + 'th of September')
        
import matplotlib.pyplot as plt # standard short name
import random

plt.ion() # sets “interactive on”: figures redrawn when updated

def picks():
    a = [] # make an empty list

    # Why all the brackets below? 
    # a += [  brackets here to add an iterable onto a list      ]
    #    random.choice(   [brackets here to choose from a list] )
    a += [random.choice([1, 3, 10])]

    for choices in range(5):
        a += [random.choice([1, 3, 10])]

    plt.hist(a)
    plt.show()
    
def roll_hundred_pair():
    total = []
    potential_roles = [1,2,3,4,5,6]
    for choices in range(100):
        total += [random.choice(potential_roles)]
    
    plt.hist(total)
    plt.show()
    
def dice(n):
    sum = 0
    potential_roles = [1,2,3,4,5,6]
    for choices in range(n):
        sum += random.choice(potential_roles)
    print 'Roll was ' + str(sum)

def hangman_display(guessed, secret):
    output = ''
    #for y in guessed:    
    for x in range(len(secret)):
        if ' ' == secret[x]:
            output += ' '
            #print '1 ' + output #for debugging
        elif secret[x] in guessed:
            output += secret[x]
            #print '2 ' + output #for debugging
        else:
            output += '-'
            #print '3 ' + output #for debugging
    return output
        
def matches(ticket, winners):
    matching = 0
    for number in ticket:
        if number in winners:
            matching += 1
    return matching

def report(guess, secret):
    in_place = 0
    out_place = 0
    guessed_colors = []
    correct_place_colors = []
    output = []
    for color in range(len(guess)):
        if guess[color] in secret:
            if guess[color] == secret[color]:
                in_place += 1
                correct_place_colors += guess[color]
            elif guess[color] not in correct_place_colors:
                out_place += 1
                guessed_colors += guess[color]
    output += [in_place, out_place]
    print correct_place_colors
    print guessed_colors
    return output

    

